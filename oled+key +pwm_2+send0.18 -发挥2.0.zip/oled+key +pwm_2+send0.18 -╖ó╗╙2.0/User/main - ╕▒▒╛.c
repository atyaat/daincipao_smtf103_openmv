/**
  ******************************************************************************
  * @file    OLED_I2C.c
  * @author  fire
  * @version V1.0
  * @date    2014-xx-xx
  * @brief   128*64�����OLED��ʾ���Թ��̣���������SD1306����IICͨ�ŷ�ʽ��ʾ��
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:Ұ�� ISO STM32 ������ 
  * ��̳    :http://www.firebbs.cn
  * �Ա�    :https://fire-stm32.taobao.com
	*
  *
  ******************************************************************************
  */ 
	
#include "stm32f10x.h"
#include "OLED_I2C.h"
#include "delay.h"
#include "key.h"
#include "pwm.h"
#include "send.h"
#include "usart.h"	 
#include "OPENMV.h"
#include "bsp_led.h"

extern u8 index;
u8 data2;
extern u8 RxBuffer[10];

//float jiuli_ele[100]={16.0 , 16.5 , 16.5 , 17.0 , 17.1 , 17.2 , 17.3 , 17.4 , 17.5 , 17.6 ,\
//		               17.7 , 17.8 , 17.8 , 17.8 , 17.9 , 17.9 , 18.0 , 18.3 , 18.5 , 18.7 ,\
//		               19.0 , 19.1 , 19.2 , 19.3 , 19.4 , 19.5 , 19.6 , 19.7 , 19.8 , 19.9 ,\
//		               19.9 , 20.0 , 20.5 , 21.0 , 21.1 , 21.2 , 21.3 , 21.4 , 21.5 , 21.6 ,\
//		               21.7 , 21.8 , 21.8 , 21.9 , 21.9 , 22.0 , 22.3 , 22.6 , 22.9 , 23.0 ,\
//		               23.2 , 23.3 , 23.4 , 23.5 , 23.6 , 23.8 , 24.0 , 24.4 , 24.8 , 25.0 ,\
//		               25.1 , 25.2 , 25.3 , 25.4 , 25.5 , 25.6 , 25.7 , 25.8 , 26.0 , 26.0 ,\
//		               26.1 , 26.2 , 26.3 , 26.4 , 26.5 , 26.6 , 26.7 , 26.8 , 26.8 , 27.0 ,\
//		               27.2 , 27.6 , 28.0 , 28.5 , 29.0 , 29.5 , 30.1 , 30.2 , 30.3 , 30.4 ,\
//		               30.5 , 30.7 , 31.0 , 31.2 , 31.3 , 31.4 , 31.5 , 31.6 , 31.7 , 32.0 ,};

int main(void)
{

	int i;
		
u16	level_angle;   //����ˮƽ��pwm����
u16	elevation_angle; //��������pwm�Ĳ���
u8 kkk;
u8 testtt = 80;
//unsigned char	trun ; 
unsigned char kflag = 0,Distence = 90,dis = 0,turn = 90,ele = 90;
	

 float jiuli_ele[100]={16.0 , 16.5 , 16.5 , 17.0 , 17.1 , 17.2 , 17.3 , 17.4 , 17.5 , 17.6 ,\
		               17.7 , 17.8 , 17.8 , 17.8 , 17.9 , 17.9 , 18.0 , 18.3 , 18.5 , 18.7 ,\
		               19.0 , 19.1 , 19.2 , 19.3 , 19.4 , 19.5 , 19.6 , 19.7 , 19.8 , 19.9 ,\
		               19.9 , 20.0 , 20.5 , 21.0 , 21.1 , 21.2 , 21.3 , 21.4 , 21.5 , 21.6 ,\
		               21.7 , 21.8 , 21.8 , 21.9 , 21.9 , 22.0 , 22.3 , 22.6 , 22.9 , 23.0 ,\
		               23.2 , 23.3 , 23.4 , 23.5 , 23.6 , 23.8 , 24.0 , 24.4 , 24.8 , 25.0 ,\
		               25.1 , 25.2 , 25.3 , 25.4 , 25.5 , 25.6 , 25.7 , 25.8 , 26.0 , 26.0 ,\
		               26.1 , 26.2 , 26.3 , 26.4 , 26.5 , 26.6 , 26.7 , 26.8 , 26.8 , 27.0 ,\
		               27.2 , 27.6 , 28.0 , 28.5 , 29.0 , 29.5 , 30.1 , 30.2 , 30.3 , 30.4 ,\
		               30.5 , 30.7 , 31.0 , 31.2 , 31.3 , 31.4 , 31.5 , 31.6 , 31.7 , 32.0 ,};
	//************************************************************
	LED_GPIO_Config();
	uart3_init(115200);		//PB10 11 ��������openmv���� ���������ڴ����ж�����
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	

//	   if(0x0898<dist<0x0d48)
//	   {
//	    dis = (int)dist-0x0898/(0x0d48-0x0898)*340-220;
//	   }
	//************************************************************				   
					   
    TIM1_PWM_Init(9999,143);//����Ƶ��PWMƵ��=72 000 0/(14399+1)=50hz 
    TIM8_PWM_Init(9999,143);
	 
	
	DelayInit();
	I2C_Configuration();
	//OLED_Init();
  //  OLED_CLS();//����
    SEND_Configration() ;
	
	while(1)
	{
				    
		
		level_angle = 1249 - turn*1000/180;
		kkk = testtt - 1;
                        TIM_SetCompare1(TIM1,level_angle);
						 
						dis = jiuli_ele[index - 1];				 
						ele = dis+90; 
					    elevation_angle = 1249 - ele*1000/180;
						TIM_SetCompare2(TIM8,elevation_angle);
	
		OLED_ShowStr(8,1,(unsigned char*)"key_mode:",2);				//����6*8�ַ�
		OLED_ShowStr(48,3,(unsigned char*)"dis:",2);		
		OLED_ShowStr(40,5,(unsigned char*)"turn:",2);
        OLED_ShowintNum(88,2,kflag,1)	;
		OLED_ShowintNum(88,4,dis,1)	;
		OLED_ShowintNum(88,6,turn-Distence,1)	;

    //***************************************************************************************		
				if(key_flag4()==1 && kflag != 0 && kflag != 4)	
					{						
				 	  DelayMs(10);
				     if(key_flag4() == 1)
					 {

					    level_angle = 1249 - turn*1000/180;
                        TIM_SetCompare1(TIM1,level_angle);
						 
						dis = jiuli_ele[index - 1];				 
						ele = dis+90; 
					    elevation_angle = 1249 - ele*1000/180;
						TIM_SetCompare2(TIM8,elevation_angle);
						 
						DelayMs(1000);
						send_ON;
						DelayMs(600);
						send_OFF;
					}
				}
		     
		
		 if(key_flag1()==1)
			{
			  DelayMs(10);
				if(key_flag1()==1)
        {	
				     while(key_flag1()==1);
				     if(kflag<3)
				     {
					        kflag++;
	    	     }
				else kflag = 0;
			   }
		   }
			
		   
		   switch(kflag)
		   {
//			   case 0:;                       //�Զ�Ѱ��Ŀ�� openmv����ˮƽ�� �����ؾ���
//			   if(key_flag4() == 1)
//				   DelayMs(10);
//			   if(key_flag4() == 1)
//			   {
//			      //�ȴ�openmv���ؾ��룬
//			   }
			   
			   case 1:;
			  if(key_flag2()==1)
				DelayMs(10);
				if(key_flag2()==1)
				{
					 dis++;
							DelayMs(100);
					while(key_flag2() == 1)
					{
					DelayMs(100);
						dis++;
						if(dis > 100) dis = 0;
					}	
					
				}
				else if(key_flag3()==1)							 
				{
						DelayMs(10);
					if(key_flag3()==1)
				 {
				     dis--;
					 	DelayMs(100);
					while(key_flag3()==1)
					{
					DelayMs(100);
						dis--;
						if(dis >100) dis = 100;
					}									
				  }
			     }
				//		   else if(key_flag4() == 1)
//		   {
//		        DelayMs(10);
//				if(key_flag4() == 1)
//				{
//				;
//				}
//		   }
				     break;
		 
			   case 2:;
				  if(key_flag2()==1)	  
			         DelayMs(10);
				if(key_flag2()==1)
				{
					 turn++;
						DelayMs(100);
					while(key_flag2() == 1)
					{
					DelayMs(100);
						turn++;
						if(turn > 120) turn = 60;
					}	
					
				}
                else if(key_flag3()==1)							 
				{
						DelayMs(10);
					if(key_flag3()==1)
				{
				     turn--;
						DelayMs(100);
					while(key_flag3()==1)
					{
					DelayMs(100);
					turn--;
						if(turn < 60) turn = 120;
					}									

				}
			}
		       
			   case 3:;
			  if(key_flag4()==1)	  
			         DelayMs(10);
				if(key_flag4()==1)
				{
					
//					whlie(openmvfas suju )
			for(i = 1915; i < 1083; i-=5)
		{
					
		TIM_SetCompare1(TIM1,i);
			DelayMs(50);
		}
		
			for(i = 1083; i<1915; i+=5)
   		{
			
		TIM_SetCompare1(TIM1,i);
			DelayMs(50);
		}
		
				}
				
		   }
					

			}
}	