#include "key.h"

//������PA0
void key_inil(void)
{
		
		GPIO_InitTypeDef KEY_INT;
		
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		KEY_INT.GPIO_Mode=GPIO_Mode_IPD;
		KEY_INT.GPIO_Pin=GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
		KEY_INT.GPIO_Speed=GPIO_Speed_2MHz;
		
		GPIO_Init(GPIOB,&KEY_INT);
}
//key���·���1�����𷵻�0
u8 key_flag1(void)
{ 
	u8 key_flag=0;
	key_flag=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_12);
	if(key_flag==1)
		return 1;
	else
	  return 0;

}
u8 key_flag2(void)
{ 
	u8 key_flag=0;
	key_flag=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13);
	if(key_flag==1)
		return 1;
	else
	  return 0;
	
}
u8 key_flag3(void)
{ 
	u8 key_flag=0;
	key_flag=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14);
	if(key_flag==1)
		return 1;
	else
	  return 0;
}
u8 key_flag4(void)
{ 
	u8 key_flag=0;
	key_flag=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15);
	if(key_flag==1)
		return 1;
	else
	  return 0;
}



