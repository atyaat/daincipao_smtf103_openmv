#ifndef _KEY_H
#define _KEY_H

#include "stm32f10x.h"
#include "stm32f10x_conf.h"

u8 key_flag1(void);
u8 key_flag2(void);
u8 key_flag3(void);
u8 key_flag4(void);
void key_inil(void);

#endif
