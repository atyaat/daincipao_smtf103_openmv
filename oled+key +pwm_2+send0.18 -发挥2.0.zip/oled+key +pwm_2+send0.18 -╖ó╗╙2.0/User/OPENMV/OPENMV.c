
/* Includes -----------------------------------------------------------------*/
#include "OPENMV.h"
#include "bsp_led.h"  
/* Macro definitions ---------------------------------------------------------*/

/* Struct or Class definitions -----------------------------------------------*/

/* Extern global variables ---------------------------------------------------*/

/* Global variables ----------------------------------------------------------*/
u16 boll_x;
u16 boll_y;
u16 dist;
u8 index;
u8 RxBuffer[10];
/* Function declarations -----------------------------------------------------*/


/**
* @brief  OPENMV_date_anl
* @param  ���յ�һ���ֽ�
* @retval None
*/
int OPENMV_date_anl(u8 data)
{
//	static u8 RxBuffer[10];
	static u8 state = 0;
	u8 dis;
	
   u16	level_angle;   //����ˮƽ��pwm����
   u16	elevation_angle; //��������pwm�Ĳ���

	unsigned char turn = 90;
/*ͨ�Ÿ�ʽ 0xAA 0x55 data1 data2 checkout 0x54*/	
/*����checkout=(data1+data2)�Ͱ�λ  ���� data1=0xe1,data2=0xf3,data1+data2=0x1d4,��checkout=0xd4*/
	if(state==0&&data==0xAA)
	{	state=1;
		LED_GREEN;
	
	}	
	else if(state==1&&data==0x55)
		state=2;
	else if(state==2)
	{
		RxBuffer[0]=data;//x
			state=3;
	}
	else if(state==3)
	{	
		RxBuffer[1]=data;//y
		state = 4;
		LED_RED;
	}
//	else if(state==4)
//	{	
//		RxBuffer[2]=data;//checkout
//		state = 5;
//	}

	else if(state==4&&data==0x54)
	{	
		boll_x=RxBuffer[0];
		boll_y=RxBuffer[1];
		dist=(int)(256*boll_x+boll_y);
		if ((dist >= 2000) && (dist < 3000))
			index=(dist-2000)/10;
		else
			index=0;
		
//		level_angle = 1249 - turn*1000/180;
//        TIM_SetCompare1(TIM1,level_angle);
//		dis = jiuli_ele[index - 1];;
//		elevation_angle = 1249 - (dis+90)*1000/180;
//		TIM_SetCompare2(TIM8,elevation_angle);		
		state = 0;
	}
	else
		state = 0;
	 
	return index;
}



/***************************END OF FILE************************************/

