#ifndef _OPENMV_H
#define	 _OPENMV_H

#include "sys.h" 
#include "usart.h"	
extern u16 boll_x;//��de����
extern u16 boll_y;
extern u16 dist;
extern u8 index;
extern u8 RxBuffer[10];

int OPENMV_date_anl(u8 data);
#endif

