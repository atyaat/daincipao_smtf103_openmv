
#include "send.h"

void SEND_Configration(void)                      //��ʼ������
{
	GPIO_InitTypeDef SEND_INT;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	SEND_INT.GPIO_Pin = GPIO_Pin_11;
	SEND_INT.GPIO_Speed = GPIO_Speed_50MHz;
    SEND_INT.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &SEND_INT);
}



