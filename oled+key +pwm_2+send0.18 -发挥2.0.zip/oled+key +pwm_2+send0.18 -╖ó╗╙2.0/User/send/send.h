#ifndef __send_H
#define __send_H 
#include "stm32f10x.h"
#include "stm32f10x_conf.h"

#define send_OFF		GPIO_ResetBits(GPIOA, GPIO_Pin_11)
#define send_ON      	GPIO_SetBits(GPIOA, GPIO_Pin_11)
		  

void SEND_Configration(void) ;
#endif
