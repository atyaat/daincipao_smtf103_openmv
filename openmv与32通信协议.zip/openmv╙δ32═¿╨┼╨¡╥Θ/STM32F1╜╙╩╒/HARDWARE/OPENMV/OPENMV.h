#ifndef _OPENMV_H
#define	 _OPENMV_H

#include "sys.h" 
#include "usart.h"	
extern int boll_x;//��de����
extern int boll_y;
void OPENMV_date_anl(u8 data);
#endif

