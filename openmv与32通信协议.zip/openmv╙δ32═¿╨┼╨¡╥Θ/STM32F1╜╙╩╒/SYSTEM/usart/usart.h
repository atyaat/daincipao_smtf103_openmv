#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 

void uart3_init(u32 bound);//PB10 11

#endif


