blob_THRESHOLD =(57, 76, -7, 9, 26, 48)
cabl_THRESHOLD =(2, 27, -13, 32, -39, 30)
pole_THRESHOLD =(22, 54, 23, 74, 1, 53)

import sensor, image, time , math ,struct
from pyb import UART
from pyb import LED
from struct import pack, unpack
import json

sensor.reset()
sensor.set_pixformat(sensor.RGB565) # grayscale is faster
sensor.skip_frames(time = 2000)

clock = time.clock()

uart = UART(3, 115200)

mode = 0

def date_get():                    #串口数据读取
    if uart.any():
        tmp_data = uart.read(1)
        print(tmp_data)
        return int(tmp_data)
    else :
        return 0

while(mode == 0):
    clock.tick()
    mode = date_get()

def back_nodate():                  #未检测到物体
    sumA = 0
    sumB = 0

    data = bytearray([0x41,0x43])
    uart.write(data)

    data = bytearray([0x01,0])
    for b in data:
        sumB = sumB + b
        sumA = sumA + sumB
    uart.write(data)

    data = bytearray([sumA, sumB])
    uart.write(data)

    return 1

def send_date(x,y,z):
    sumA = 0
    sumB = 0

    data = bytearray([0x41,0x43])           #包头
    uart.write(data)

    data = bytearray([0x02,12])              #数据类型与长度
    for b in data:
        sumB = sumB + b
        sumA = sumA + sumB
    uart.write(data)

    float_value = x                         #X,距离
    float_bytes = pack('f', float_value)
    for b in float_bytes:
        sumB = sumB + b
        sumA = sumA + sumB
    uart.write(float_bytes)

    float_value = y                         #Y，位置
    float_bytes = pack('f', float_value)
    for b in float_bytes:
        sumB = sumB + b
        sumA = sumA + sumB
    uart.write(float_bytes)

    float_value = z                         #返回数据类型
    float_bytes = pack('f', float_value)
    for b in float_bytes:
        sumB = sumB + b
        sumA = sumA + sumB
    uart.write(float_bytes)

    data = bytearray([sumA, sumB])          #校验和
    uart.write(data)

    return 1

while(True):
    clock.tick()
    if mode == 1:
        LED(2).on()

        #sensor.set_auto_gain(False) # must be turned off for color tracking
        #sensor.set_auto_whitebal(False) # must be turned off for color tracking
        sensor.set_framesize(sensor.QQVGA)

        comd = 0
        is_back_pol = 0
        is_back_cab = 0

        while(True):
            img = sensor.snapshot()

            poles = img.find_blobs([pole_THRESHOLD], pixels_threshold=200,merge=True)        #找红色杆子
            cable = img.find_blobs([cabl_THRESHOLD], pixels_threshold=100,merge=True)        #找黑色线缆
            blobs = img.find_blobs([blob_THRESHOLD], pixels_threshold=10,merge=True)         #找黄色异物

            if(len(poles)):
                for pol in poles:
                    img.draw_rectangle(pol.rect(),color = (0, 255, 0))  #杆子绿色

            if(len(cable)):
                for cab in cable:
                    img.draw_rectangle(cab.rect(),color = (255, 0, 0))  #线缆红色

            if(len(blobs)):
                for blo in blobs:
                    img.draw_rectangle(blo.rect(),color = (0, 0, 255))  #异物蓝色

            comd = date_get()

            if(comd == 3):
                is_back_pol = 1
                is_back_cab = 0
            elif(comd == 4):
                is_back_pol = 0
                is_back_cab = 1

            if(len(poles) and len(cable) == 0 and len(blobs) == 0):
                back_date = 1
            if(len(poles) == 0 and len(cable) and len(blobs) == 0):
                back_date = 2
            if(len(poles) and len(cable) and len(blobs) == 0):
                back_date = 3
            if(len(cable) == 2):
                back_date = 4

            if(len(poles) and is_back_pol):              #返回杆值
                send_date(350/pol.w()-35,80-pol.cx(),back_date)
                print(350/pol.w())

            if(len(cable) and is_back_cab):              #返回线值
                send_date(200/cab.w()-20,60-cab.cy(),back_date)
                print(200/cab.h())

            if(len(poles)==0 and len(cable)==0 and len(blobs)==0):
                back_nodate()

    elif mode == 2:

        LED(3).on()

        sensor.set_framesize(sensor.QQVGA)

        while(True):
            img = sensor.snapshot().lens_corr(1.8)

            cir = img.find_circles(threshold = 2500, x_margin = 60, y_margin = 60, r_margin = 30,r_min = 2, r_max = 30, r_step = 2)

            if(len(cir)):
                for c in cir:
                    img.draw_circle(c.x(), c.y(), c.r(), color = (0, 255, 0))

                hight = 1000/c.r()
                send_date(80-c.x(),60-c.y(),hight)
            else:
                back_nodate()
