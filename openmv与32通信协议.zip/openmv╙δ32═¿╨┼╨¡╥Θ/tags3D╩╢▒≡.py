import sensor, image, time ,math ,struct
from pyb import UART
from struct import pack, unpack
import json
red_threshold =(0, 33, -47, 26, -7, 39)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.skip_frames(time=2000)
sensor.set_auto_gain(False)  # must turn this off to prevent image washout...
sensor.set_auto_whitebal(False)
clock = time.clock()
uart = UART(3, 115200)
import sensor, image, time, math

f_x = (2.8 / 3.984) * 160 # find_apriltags defaults to this if not set
f_y = (2.8 / 2.952) * 120 # find_apriltags defaults to this if not set
c_x = 160 * 0.5 # find_apriltags defaults to this if not set (the image.w * 0.5)
c_y = 120 * 0.5 # find_apriltags defaults to this if not set (the image.h * 0.5)

def degrees(radians):
    return (180 * radians) / math.pi

while(True):

    clock.tick()
    img = sensor.snapshot()

    tags = img.find_apriltags(fx=f_x, fy=f_y, cx=c_x, cy=c_y) # defaults to TAG36H11

    for tag in tags:
        img.draw_rectangle(tag.rect(), color = (255, 0, 0))
        img.draw_cross(tag.cx(), tag.cy(), color = (0, 255, 0))

    if tags:
        bx_x=tag.cx()-80
        by_y=tag.cy()-60

        sumA = 0
        sumB = 0
        data = bytearray([0x41,0x43])
        uart.write(data)

        data = bytearray([0x02,8])
        for b in data:
            sumB = sumB + b
            sumA = sumA + sumB
        uart.write(data)

        float_value = bx_x
        float_bytes = pack('f', float_value)
        for b in float_bytes:
            sumB = sumB + b
            sumA = sumA + sumB
        uart.write(float_bytes)

        float_value = by_y
        float_bytes = pack('f', float_value)
        for b in float_bytes:
            sumB = sumB + b
            sumA = sumA + sumB
        uart.write(float_bytes)

        data = bytearray([sumA, sumB])
        uart.write(data)

        print("found: x=",bx_x,"  y=",by_y)
        #b_output_str="x%d%d,y%d%d" % (bx_value,bx_x,by_value,by_y)
        #print('you send black:',b_output_str)
        #uart.write(b_output_str+'\r\n')
    else:
        sumA = 0
        sumB = 0

        data = bytearray([0x41,0x43])
        uart.write(data)

        data = bytearray([0x01,0])
        for b in data:
            sumB = sumB + b
            sumA = sumA + sumB
        uart.write(data)

        data = bytearray([sumA, sumB])
        uart.write(data)
        print(sumA," ",sumB)
        #print('not found!')
        #b_output_str = "x10,y10"
        #print('you send black:',b_output_str)
        #b_output_str = "x3750,y3750"
        #uart.write(b_output_str+'\r\n')


